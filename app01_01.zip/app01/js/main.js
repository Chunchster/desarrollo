var data = {
    user: [],
    info: []
};

//Tabla

//select VehicleID, VehicleReg, VehicleType, VehicleGroup, Connected, IO_event from livedata where VehicleReg = 'C6F-718';
//

//Exportar
$("#data-export").click(function (e) {
    e.stopPropagation()
    var exportData = JSON.stringify({
        user: data.user,
        consulta: data.info
    });
    var target = $(this);
    var link = $("<a></a>")
        .addClass("exportLink")
        .click(function (e) { e.stopPropagation(); })
        .attr('target', '_self')
        .attr("download", "data.json")
        .attr("href", "data:application/json," + exportData)

    link.appendTo(target).get(0).click();

    $(".exportLink").remove();

});

//Tabla
$("#getevents").on('click',function () {
   
    var valueplaca = $("#placa").val().toUpperCase().trim();
    clearTable();

    if (valueplaca == ''){
      alert("Por favor ingresa la placa vehicular");  
    }
    else {
        consulta(valueplaca);
    }
    
});

function clearTable() {
    data.user = [];
    data.info = [];
};

function consulta(name) {

    
};